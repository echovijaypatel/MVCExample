﻿var TableEditable = function () {
    var uploadDocumentTable = $('#tblAnimalHusbandryDocument');
    var standardHTML = '';
    var mediumHTML = '';
    var sectionHtml = '';
    var handleAnimalHusbandryDocumentTable = function () {
      
        //Binding datatable.
        var uploadDocumentDatatable = uploadDocumentTable.dataTable({
            "lengthMenu": [
                [5, 15, 20, -1],
                [5, 15, 20, "All"] // change per page values here
            ],

            // set the initial value
            "pageLength": 10,

            "language": {
                "lengthMenu": " _MENU_ records"
            },
            "columnDefs": [{ // set default column settings
                'orderable': true,
                'targets': [0]
            }, {
                "searchable": true,
                "targets": [0]
            }],
            bSort: false,
            "order": [
                [0, "asc"]
            ] // set first column as a default sort by asc
        });

        var tablestudentTeacherWrapper = $("#tblAnimalHusbandryDocument_wrapper");

        //Binding no of records.
        tablestudentTeacherWrapper.find(".dataTables_length select").select2({
            showSearchInput: true //hide search box with special css class
        }); // initialize select2 dropdown

        //Binding add event.
        $('#btnAddFirst').click(function (e) {
            if (documentListHTML != "" ) {
                table1Count++;
                console.log("table1Count:" + table1Count);
                e.preventDefault();
                var aiNew = uploadDocumentDatatable.fnAddData(['', '', '', '','']);
                var nRow = uploadDocumentDatatable.fnGetNodes(aiNew[0]);
                editUploadDocumentRow(uploadDocumentDatatable, nRow);
                resetUploadDocumentIndexAfterDelete();
            } else {
                alert("Fail to download Standard and Medium data.");
            }
        });

        //Binding delete event.
        tablestudentTeacherWrapper.on('click', '.btnDelete', function (e) {
            e.preventDefault();
            if (confirm("Are you sure to delete this row ?") == false) {
                return;
            }
            var nRow = $(this).parents('tr')[0];
            uploadDocumentDatatable.fnDeleteRow(nRow);
            resetUploadDocumentIndexAfterDelete();
        });

        //Binding mvc model while adding row.
        function editUploadDocumentRow(uploadDocumentDatatable, nRow) {

            var aData = uploadDocumentDatatable.fnGetData(nRow);
            var jqTds = $('>td', nRow);
            jqTds[0].innerHTML = table1Count + 1;
            //jqTds[1].innerHTML = '<input type="text" class="form-control" onkeypress = "return isNumberKey(event)" name="DetailsOfStudentAndTeachers[' + table1Count + '].Standard" placeholder="Standard" value="' + aData[1] + '">';
            jqTds[1].innerHTML = '<select class="form-control ddlDocument"  id="LstUploadDocument' + table1Count + '_DocumentID" name="LstUploadDocument[' + table1Count + '].DocumentID">' + documentListHTML + '</select>';
            jqTds[2].innerHTML = '<input type="text" class="form-control otherDocument" Value="" style="display:none"  name="LstUploadDocument[' + table1Count + '].DocumentName" placeholder="Enter Other Document Name">';
            jqTds[3].innerHTML = '<input type="file" class="form-control NoOfClasses" Value="0"  name="LstUploadDocument[' + table1Count + '].Document" placeholder="Total Classes">';
            jqTds[4].innerHTML = "<input type='button' class='btn btn-danger btnDelete' value='Delete'/>";

        }

        //Reset model index for mvc list.
        function resetUploadDocumentIndexAfterDelete() {
            table1Count = -1;
            var allRows = $("#tblAnimalHusbandryDocument tbody tr");
            if (typeof (allRows) != 'undefined' && allRows != null && allRows.length > 0) {
                for (var i = 0; i < allRows.length; i++) {
                    table1Count++;
                    console.log("table1Count:" + table1Count);
                    var $row = $(allRows[i]);
                    var td = $row.find("td:first");
                    if (!$(td).hasClass("dataTables_empty")) {
                        $(td).html(table1Count + 1);
                    }
                    $row.find('td').first().html(i + 1);
                                     var allDDL = $row.find('select');
                    allDDL.each(function (i, v) {
                        var currentName = $(v).attr('name');
                        if (currentName) {
                            var index = currentName.indexOf("]");
                            var newName = "LstUploadDocument[" + table1Count + currentName.substr(index);
                            $(v).attr('name', newName);
                        }
                    });

                    var allInput = $row.find('input');
                    allInput.each(function (i, v) {
                        var currentName = $(v).attr('name');
                        if (currentName) {
                            var index = currentName.indexOf("]");
                            var newName = "LstUploadDocument[" + table1Count + currentName.substr(index);
                            $(v).attr('name', newName);
                        }
                    });
                }
            }
        }
    }

    
    function GetDetailsOfStudentAndTeachers() {
        //standardHTML = '<option value="">Select</option>';
        //standardHTML += '<option value="1">Certificate 1</option>';
        //standardHTML += '<option value="2">Certificate 2</option>';
        //standardHTML += '<option value="3">Certificate 3</option>';
        //standardHTML += '<option value="4">Certificate 4</option>';
        //standardHTML += '<option value="5">Certificate 5</option>';
       
    }
    return {
        //main function to initiate the module
        init: function () {
            handleAnimalHusbandryDocumentTable();
           
        }
    };
}();