function one() {
    alert('one');
}