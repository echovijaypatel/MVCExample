function two() {
    alert('two');
}