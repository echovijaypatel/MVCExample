function three() {
    alert('three');
}